﻿using TiaPortalOpennessDemo.ViewModels;

namespace TiaPortalOpennessDemo.Views
{
    public sealed partial class MainWindow
    {
        /// <summary>
        /// 
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainWindowViewModel();
        }
    }
}
