﻿
namespace TiaPortalOpennessDemo.Views
{
    public partial class SettingsView
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataContext"></param>
        public SettingsView(object dataContext)
        {
            DataContext = dataContext;
            InitializeComponent();
        }
    }
}
