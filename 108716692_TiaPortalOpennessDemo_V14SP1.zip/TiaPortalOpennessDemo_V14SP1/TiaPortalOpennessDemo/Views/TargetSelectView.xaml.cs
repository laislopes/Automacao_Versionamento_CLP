﻿
namespace TiaPortalOpennessDemo.Views
{
    public sealed partial class TargetSelectView
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataContext"></param>
        public TargetSelectView(object dataContext)
        {
            InitializeComponent();
            DataContext = dataContext;
        }
    }
}
