﻿
namespace TiaPortalOpennessDemo.Views
{
    public sealed partial class ConnectionConfigurationView
    {
        /// <summary>
        /// 
        /// </summary>
        public ConnectionConfigurationView()
        {
            InitializeComponent();
        }
    }
}
