﻿
namespace TiaPortalOpennessDemo.Views
{
    public sealed partial class Overlay
    { 
        /// <summary>
        /// 
        /// </summary>
        public Overlay()
        {
            InitializeComponent();
        }
    }
}
